# ICA2027五图交付：十组主实验与消融

图1、2为现实内容分析；图3、4为每制度10个种子的30次主运行。图5为兴趣制度Full/B=0/D=1/R=1各10种子，配对复用主实验Full。SVG文字和路径可编辑，PDF同为矢量，PNG只作预览。插入Word请锁定纵横比。

CAPTIONS_ZH.md为五段中文图注；REVISION_ADVICE.md为正文数字与论证修改意见。其涉及旧稿/延后资料的链接只在原run完整目录可用，本包不包含原Word与旧图5。

source_data保存冻结CSV与来源；scripts/gen_fig1.py—gen_fig5.py按顺序离线重绘，依赖Python、Matplotlib、Pandas、NumPy、Pillow和Times New Roman（缺失时使用字体fallback）。无需重跑仿真。qa保存数据与图件检查。
